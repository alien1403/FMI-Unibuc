package com.example.instagram_analytics

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
